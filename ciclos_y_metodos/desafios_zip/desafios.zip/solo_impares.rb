n = ARGV[0].to_i


for i in 1..n
    a = (i*2)-1
    print "#{a} "
end

puts


