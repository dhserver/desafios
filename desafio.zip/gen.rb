n = ARGV[0].to_i

inicio = "a"
# i=0
# while f != p 
#     f = f.next 
#     i += 1
#     # puts i
# end

for i in (1..n)
    inicio = inicio.next
    i += 1
    # puts i 
    print "a #{inicio} "
end
puts
